export class Student{
    "id":number 
    "name":string 
    "gender":string
    "course":string
    "phoneNumber":number
    "email":string
    "comments":string
    "notification":boolean
    "dob":Date
    "actions": string 
}